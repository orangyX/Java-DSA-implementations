package heap;
public interface HeapInterface<T> {
    int size();
    T peek();
    void put(T item);
    T removeMin();
}
